viewDietPlansButton.addEventListener('click', function() {
  dietPlanSection.style.display = 'block';  // Show the diet plan section
});


